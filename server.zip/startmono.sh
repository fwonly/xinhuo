#!/bin/sh
fastcgi-mono-server4 /applications=/:/usr/www/    /socket=tcp:127.0.0.1:9001
#重新执行
startmono.sh
